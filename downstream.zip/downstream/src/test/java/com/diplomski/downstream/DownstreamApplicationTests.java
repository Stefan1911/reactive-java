package com.diplomski.downstream;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DownstreamApplicationTests {

	@Test
	void contextLoads() {
	}

}
